# PFAS 3D structure sources

Thirty-seven bundled structures are PubChem's own computed conformers (the
first, default conformer of each CID), retrieved from the official PUG REST
service and shipped with the package so the interface makes no network request
at runtime. Each can be regenerated from:

`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{CID}/SDF?record_type=3d`

PubChem still returned HTTP 404 for the 3D record of NEtFOSA, PFDoA, PFDS,
PFNS, PFODA, PFUnA, 8:2 FTSA, and 11Cl-PF3OUdS when rechecked on 2026-10-03.
For those eight compounds, the exact PubChem InChIKey was submitted to the
official NCI/CADD Chemical Identifier Resolver, requesting a generated 3D SDF:

`https://cactus.nci.nih.gov/chemical/structure/{InChIKey}/file?format=sdf&get3d=true`

They are recorded separately below and must not be described as PubChem
conformers. PubChem data are in the public domain.

## NCI/CADD-generated 3D structures

| PFAS | PubChem CID | PubChem InChIKey | File | SHA-256 |
|---|---:|---|---|---|
| NEtFOSA | 77797 | `CCEKAJIANROZEO-UHFFFAOYSA-N` | `NEtFOSA.sdf` | `8965c57b232e3ad856bc7ad69532a80b8803641d6cc9c6fb793293d5cfcba0ce` |
| PFDoA | 67545 | `CXGONMQFMIYUJR-UHFFFAOYSA-N` | `PFDoA.sdf` | `6e10d2c3a819349be37cce907febaafa2ec7f8534d5edf6e93d6625a86d924fb` |
| PFDS | 67636 | `HYWZIAVPBSTISZ-UHFFFAOYSA-N` | `PFDS.sdf` | `f1600a99e05d5f8ea150f032df7765ced4602f163debd7eec514768ffc476b97` |
| PFNS | 86998 | `MNEXVZFQQPKDHC-UHFFFAOYSA-N` | `PFNS.sdf` | `0a95c4c1ea77fbe3504ac85a79c88a671c734bfe10fd192141e3e870f1ef75b2` |
| PFODA | 167547 | `ZTSDOGSKTICNPQ-UHFFFAOYSA-N` | `PFODA.sdf` | `952ce76b38641bb72c04daba872e72a2cf582cced567914d7b0a5eb89dee482f` |
| PFUnA | 77222 | `SIDINRCMMRKXGQ-UHFFFAOYSA-N` | `PFUnA.sdf` | `174a342dc709a5b1107c70712880f4995bc22c93380ea5b6d0e10ae38bc6ba82` |
| 8:2 FTSA | 3016044 | `ALVYVCQIFHTIRD-UHFFFAOYSA-N` | `8_2_FTSA.sdf` | `ca69a4427b6d4fb46d719aa3d6271d78670b6d9c2b5c39bded5a5a29285e8ae7` |
| 11Cl-PF3OUdS | 15099039 | `SZVGIJOITCPDPM-UHFFFAOYSA-N` | `11Cl-PF3OUdS.sdf` | `07974bbdb662ba923979d7032566db1784344a376bfc8475d6f22a108eea10e0` |

## PubChem-computed 3D conformers

| PFAS | PubChem CID | File | SHA-256 |
|---|---:|---|---|
| ADONA | 52915299 | `ADONA.sdf` | `4bfb58f36276f024dff95b5dcd0a81738fa046e8116bf2cad39437561794c34d` |
| GenX | 114481 | `GenX.sdf` | `7d0df00fe3b550886c49d77fc4d8f7e68dd5e056e63eef80b58b495a735f6898` |
| NEtFOSAA | 18134 | `NEtFOSAA.sdf` | `b6c723d873967a03a692b6d0a750bd235bf2aa6df2a7b83f1c9b213a72b704b0` |
| NEtFOSE | 74322 | `NEtFOSE.sdf` | `e2021d15a3ec761521cdb43e291816b26fb61dcb9ef58f589676bac4ef7300eb` |
| NFDHA | 2782393 | `NFDHA.sdf` | `c8529b0eb4740eaa8a177e7bd15d654c9db3df32d6f7ad52978c79ef9dbafc15` |
| NMeFOSA | 3034468 | `NMeFOSA.sdf` | `f64eee95c23a3431643433affc9bebb292735c5e04b0de876e64fbc2072b1b2c` |
| NMeFOSAA | 22286931 | `NMeFOSAA.sdf` | `77a963cccf66e6515959a5beefd38d66c9eb84fe12600767dcad3028fda11fc8` |
| NMeFOSE | 90507 | `NMeFOSE.sdf` | `f5ba4f58df34b47ebf695fc6049f9605c4663d551252b84ab9fc34c52db0a683` |
| PFBA | 9777 | `PFBA.sdf` | `d25ba2b689cbdef78cccf099937e24406d3737dc790727de7b81bc3d1a649808` |
| PFBS | 67815 | `PFBS.sdf` | `6b4d17b5f190288b7c46f2c4533731060ec917ea7721ab880c2f1fbff6fb2318` |
| PFDA | 9555 | `PFDA.sdf` | `9f39f42c05ea22c357132579e39e0d58b385bbe950d015c6f727cf0f27eec4e3` |
| PFDoS | 3018866 | `PFDoS.sdf` | `a0a4cfba5621d867bd581fb68944dd6934096cb86e3e6fe14af441a4f0f47065` |
| PFEESA | 2776108 | `PFEESA.sdf` | `a430f39caacc0a0dda4c66fe5fce0b2bb7c49f34d46776a250a016055c129b5c` |
| PFHpA | 67818 | `PFHpA.sdf` | `9616e1e53b2b717f9f58c9858ce097ad84ae18d02c82765c5528274ee6f5b7aa` |
| PFHpS | 67820 | `PFHpS.sdf` | `6e4a6f61490410c0bfbaf20f8ea9cb737374077d8a8d0ddb15b0dba1f683ab63` |
| PFHxA | 67542 | `PFHxA.sdf` | `38d92bf5e908c8dac063daf8c7474ad368c93584c41dcc31382212b6ebb18cb9` |
| PFHxDa | 106027 | `PFHxDa.sdf` | `458fd3a37e36f7811fe36cfa1c571e6f9bb219dfc0b688ef614221757484eb49` |
| PFHxS | 67734 | `PFHxS.sdf` | `d53b7175fbfd9d810ebcbe0fd8265aa37323ea487b6c10b1afbf6ac9a9cf4c13` |
| PFMBA | 12498036 | `PFMBA.sdf` | `41d61f95d60b09b4def1f0c2ae535aba9849a81cf8c15e25a64b6bf410aec28c` |
| PFMPA | 120228 | `PFMPA.sdf` | `e88bf982e96dd58510c4d38162051fcf991594b0dbb8b735d103ecc805f79ccd` |
| PFNA | 67821 | `PFNA.sdf` | `093b2859682e22b1d9cce81b20ed5b4ee0ef56c1a4d575b25e32dffd6f223ad5` |
| PFOA | 9554 | `PFOA.sdf` | `6cded43ea18861cc9a4d003ef140c629762079f39a89ceff556eb658d63a271d` |
| PFOS | 74483 | `PFOS.sdf` | `975d6d034901be424d6c31e9f0128575b65e58e07a26980c277e98a76db82613` |
| PFOSA | 69785 | `PFOSA.sdf` | `0b9f80d5953123a86e58ddf7406cbe06098a6d4f23385748fbd5a36202a7480e` |
| PFPeA | 75921 | `PFPeA.sdf` | `c73f7b9345ad00a4a1d68db3824728297e601851fd691894c88833dec163c03b` |
| PFPeS | 75922 | `PFPeS.sdf` | `29cc3eb1a2d5e661efda7ecbe2a6e890f9c400370dccee4c1536be11755975a2` |
| PFPrA | 62356 | `PFPrA.sdf` | `51ced6d9fdd272a6f1a278004441af06a8bb35d39270e764e57dc596acf77f07` |
| PFTeDA | 67822 | `PFTeDA.sdf` | `8b9cf65226f6cbd9650f907e34cc6993bbc65ee973dea84aeed4bac8e127c873` |
| PFTrDA | 3018355 | `PFTrDA.sdf` | `3996c282e0ceef91f4b472cee9fece4c9d15f531d92dfe5104f40ceae263e062` |
| PFTrDS | 21964789 | `PFTrDS.sdf` | `098b75b8ce349d3b1696b74d163119c08e5df76d4da9065c0b6d77e2a247a683` |
| TSFI | 157857 | `TSFI.sdf` | `1ec075d67366b316eaab730d6741811d559d83be65d0585e76f33a6fa598cbd8` |
| 3:3 FTCA | 2774909 | `3_3_FTCA.sdf` | `a64916e924b11736869e03214851c20698261fcae8e9c348d07650f0daa882af` |
| 4:2 FTSA | 20734543 | `4_2_FTSA.sdf` | `b85c2f39cb73640e876d5165f06b1fb75b1c5ad074d991e37a9907e12e002630` |
| 5:3 FTCA | 14632790 | `5_3_FTCA.sdf` | `e381d7ea0d5afd1e7f2bd7932840c869990051740e5f9d0eb15ddf859cbb3948` |
| 6:2 FTSA | 119688 | `6_2_FTSA.sdf` | `8d3e4e1b6e7ed7713704b4cab297fe925157fed33efc5cafcb9a771cf5d52163` |
| 7:3 FTCA | 2783376 | `7_3_FTCA.sdf` | `043916123007e69e2e10eb4f040a4ced196f0b425a6649e20e78d1844ae0ec73` |
| 9Cl-PF3ONS | 22568738 | `9Cl-PF3ONS.sdf` | `2be4179295a600d9b19d6ecd3cfc3cada6c93b3985dcbbda43c444b32d96d34a` |
