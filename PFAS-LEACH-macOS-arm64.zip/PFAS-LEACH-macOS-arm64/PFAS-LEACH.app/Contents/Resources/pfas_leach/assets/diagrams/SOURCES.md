# Diagrams

`conceptual_model.svg` — the PFAS-LEACH conceptual model figure, supplied by the
repository owner and stored byte-for-byte as given. Last replaced 2026-09-16;
1829 × 1572, with one raster image embedded as a data URI.

It has no `viewBox`. That is not a problem where it is used: an `<img>` derives
the intrinsic aspect ratio from the `width` and `height` attributes, so a width
in CSS with `height: auto` scales it correctly. It would matter if the file were
ever inlined into the page as markup instead — and it is deliberately not, see
the note beside it in `web/ui.py`.
