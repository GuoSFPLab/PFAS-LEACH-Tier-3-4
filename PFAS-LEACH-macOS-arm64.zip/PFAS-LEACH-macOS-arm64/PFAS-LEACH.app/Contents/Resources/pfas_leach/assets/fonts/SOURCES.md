# Bundled fonts

| File | Family | Source | Version | SHA-256 |
|---|---|---|---|---|
| `Geist-Variable.woff2` | Geist Sans (variable, weight 100-900) | npm `geist`, `dist/fonts/geist-sans/Geist-Variable.woff2` | 1.7.2 | `a369fcf5628ea2aa4e1b9e2ec6a5b3624e365bda588e1f0f2f12b564f728fbb8` |
| `GoogleSansFlex-Latin-Variable.woff2` | Google Sans Flex (variable, weight 100-1000, Latin subset) | Google Fonts API `css2?family=Google+Sans+Flex`, `latin` subset, fonts.gstatic.com v22 | v22 | `5dd2c8c51dee0eb9f66814d89af270f545a270149990c68dba524395e6f893fb` |

Both are licensed under the SIL Open Font License 1.1. Geist's copy is
`LICENSE.txt` (Copyright (c) 2023 Vercel, in collaboration with
basement.studio); Google Sans Flex's is `LICENSE-GoogleSansFlex.txt`
(Copyright 2015 The Google Sans Flex Authors), taken verbatim from
`google/fonts`, `ofl/googlesansflex/OFL.txt`.

Geist sets the interface. Google Sans Flex sets only the Overview's reading
box - the long-form text there follows the owner's chosen reference, the body
text of deepmind.google's blog.

The file is **bundled, not fetched**. The application makes no network request
at runtime, so a webfont served from a CDN would leave the interface rendering
in a fallback face on any machine without internet - and would send a request
the tool has no reason to make. One variable file covers every weight the
interface uses, which is why the static cuts are not shipped.
