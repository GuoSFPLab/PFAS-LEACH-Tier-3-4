# Bundled JavaScript

| File | Library | Source | Version | SHA-256 |
|---|---|---|---|---|
| `3Dmol-min.js` | 3Dmol.js molecular viewer | npm `3dmol`, `build/3Dmol-min.js` (via cdn.jsdelivr.net) | 2.5.5 | `f7cc78921ae72e7623e89cdd111434f58c2efddd2ffda1cd212644b406fb8016` |

3Dmol.js is licensed under the BSD-3-Clause license, copied verbatim in
`3Dmol-LICENSE.txt`; the notices for the code it bundles are in
`3Dmol-min.js.LICENSE.txt`, as the file's own header points to.

It draws the rotatable 3D structure of the selected PFAS in the PFAS Property
capsule, from the PubChem conformers in `../pfas3d/`. Bundled, not fetched: the
application makes no network request at runtime.
