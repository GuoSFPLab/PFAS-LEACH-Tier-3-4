PFAS-LEACH 1.1 for Windows x64

Extract the entire ZIP to a writable folder, then open PFAS-LEACH.exe. Keep the _internal folder beside the executable.

First launch: Windows SmartScreen may warn because this app is not signed. Choose "More info", then "Run anyway" if you trust this download.

Requires Windows x64, Microsoft Edge WebView2 Runtime, and Microsoft .NET Framework 4.8. Python is bundled with the app.

The application opens in its own desktop window. User Guide links open in your default browser while the app is running.

Distribution license: CC BY-ND 4.0. See LICENSE.txt. Dependency notices are in THIRD_PARTY_LICENSES.
University of Arizona, Bo Guo Research Group.
