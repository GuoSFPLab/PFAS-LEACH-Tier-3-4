# PubChem molecular-image sources

The bundled 2D molecular depictions were retrieved from the official PubChem PUG REST
service. Each image corresponds to the CID below and can be regenerated from:

`https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{CID}/PNG?record_type=2d&image_size=large`

| PFAS | PubChem CID |
|---|---:|
| ADONA | 52915299 |
| GenX (HFPO-DA acid) | 114481 |
| NEtFOSA | 77797 |
| NEtFOSAA | 18134 |
| NEtFOSE | 74322 |
| NFDHA | 2782393 |
| NMeFOSA | 3034468 |
| NMeFOSAA | 22286931 |
| NMeFOSE | 90507 |
| PFBA | 9777 |
| PFBS | 67815 |
| PFDA | 9555 |
| PFDoA | 67545 |
| PFDoS | 3018866 |
| PFDS | 67636 |
| PFEESA | 2776108 |
| PFHpA | 67818 |
| PFHpS | 67820 |
| PFHxA | 67542 |
| PFHxDa | 106027 |
| PFHxS | 67734 |
| PFMBA | 12498036 |
| PFMPA | 120228 |
| PFNA | 67821 |
| PFNS | 86998 |
| PFOA | 9554 |
| PFODA | 167547 |
| PFOS | 74483 |
| PFOSA | 69785 |
| PFPeA | 75921 |
| PFPeS | 75922 |
| PFPrA | 62356 |
| PFTeDA | 67822 |
| PFTrDA | 3018355 |
| PFTrDS | 21964789 |
| PFUnA | 77222 |
| TSFI | 157857 |
| 3:3 FTCA | 2774909 |
| 4:2 FTSA | 20734543 |
| 5:3 FTCA | 14632790 |
| 6:2 FTSA | 119688 |
| 7:3 FTCA | 2783376 |
| 8:2 FTSA | 3016044 |
| 9Cl-PF3ONS | 22568738 |
| 11Cl-PF3OUdS | 15099039 |

PubChem pages and depictions should be rechecked when adding aliases, salts, or isomeric
forms. The present mapping follows the neutral/acid form used for the Excel property row.
